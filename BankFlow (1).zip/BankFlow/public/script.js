
// Sample data
const accounts = [
    {
        id: '1',
        name: 'Business Checking',
        type: 'checking',
        balance: 45250.75,
        accountNumber: '****1234'
    },
    {
        id: '2',
        name: 'Business Savings',
        type: 'savings',
        balance: 125000.00,
        accountNumber: '****5678'
    },
    {
        id: '3',
        name: 'Business Credit',
        type: 'credit',
        balance: 8500.00,
        creditLimit: 25000.00,
        accountNumber: '****9012'
    }
];

const transactions = [
    {
        id: '1',
        accountId: '1',
        type: 'credit',
        amount: 2500.00,
        description: 'Client Payment - Invoice #1234',
        date: '2024-01-15',
        category: 'Income'
    },
    {
        id: '2',
        accountId: '1',
        type: 'debit',
        amount: 450.00,
        description: 'Office Supplies - Staples',
        date: '2024-01-14',
        category: 'Office Expenses'
    },
    {
        id: '3',
        accountId: '2',
        type: 'credit',
        amount: 10000.00,
        description: 'Transfer from Checking',
        date: '2024-01-13',
        category: 'Transfer'
    },
    {
        id: '4',
        accountId: '3',
        type: 'debit',
        amount: 1200.00,
        description: 'Marketing - Google Ads',
        date: '2024-01-12',
        category: 'Marketing'
    },
    {
        id: '5',
        accountId: '1',
        type: 'debit',
        amount: 750.00,
        description: 'Utilities - Electric Company',
        date: '2024-01-11',
        category: 'Utilities'
    }
];

let currentUser = null;

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

// Authentication
function login(username, password) {
    if (username === 'demo' && password === 'demo') {
        currentUser = { id: '1', name: 'Demo User', username: 'demo' };
        localStorage.setItem('user', JSON.stringify(currentUser));
        showMainApp();
        return true;
    }
    return false;
}

function logout() {
    currentUser = null;
    localStorage.removeItem('user');
    showLogin();
}

function checkAuth() {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        showMainApp();
    } else {
        showLogin();
    }
}

function showLogin() {
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('mainApp').style.display = 'none';
}

function showMainApp() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('mainApp').style.display = 'flex';
    loadDashboard();
}

// Navigation
function showPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    document.getElementById(pageName + 'Page').classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageName}"]`).classList.add('active');
    
    // Update page title
    const titles = {
        dashboard: 'Dashboard',
        accounts: 'Accounts',
        transfers: 'Transfers',
        payments: 'Payments',
        analytics: 'Analytics'
    };
    document.getElementById('pageTitle').textContent = titles[pageName];
    
    // Load page content
    switch(pageName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'accounts':
            loadAccounts();
            break;
        case 'transfers':
            loadTransfers();
            break;
        case 'payments':
            loadPayments();
            break;
        case 'analytics':
            loadAnalytics();
            break;
    }
}

// Dashboard
function loadDashboard() {
    renderAccountCards();
    renderRecentTransactions();
}

function renderAccountCards() {
    const container = document.getElementById('accountCards');
    container.innerHTML = '';
    
    accounts.forEach(account => {
        const card = document.createElement('div');
        card.className = `account-card ${account.type}-card`;
        
        let cardContent = `
            <div class="account-type">${account.name}</div>
            <div class="account-balance">${formatCurrency(account.balance)}</div>
            <div class="account-number">${account.accountNumber}</div>
        `;
        
        if (account.type === 'credit') {
            const usagePercent = (account.balance / account.creditLimit) * 100;
            cardContent += `
                <div class="credit-usage">
                    <div class="credit-usage-label">Credit Used: ${formatCurrency(account.balance)} of ${formatCurrency(account.creditLimit)}</div>
                    <div class="credit-usage-bar">
                        <div class="credit-usage-fill" style="width: ${Math.min(usagePercent, 100)}%"></div>
                    </div>
                </div>
            `;
        }
        
        card.innerHTML = cardContent;
        container.appendChild(card);
    });
}

function renderRecentTransactions() {
    const container = document.getElementById('transactionsList');
    container.innerHTML = '';
    
    const recentTransactions = transactions.slice(0, 5);
    
    recentTransactions.forEach(transaction => {
        const item = document.createElement('div');
        item.className = 'transaction-item';
        
        item.innerHTML = `
            <div class="transaction-details">
                <h4>${transaction.description}</h4>
                <p>${formatDate(transaction.date)} • ${transaction.category}</p>
            </div>
            <div class="transaction-amount ${transaction.type}">
                ${transaction.type === 'credit' ? '+' : '-'}${formatCurrency(transaction.amount)}
            </div>
        `;
        
        container.appendChild(item);
    });
}

// Accounts
function loadAccounts() {
    const container = document.getElementById('accountsGrid');
    container.innerHTML = '';
    
    accounts.forEach(account => {
        const card = document.createElement('div');
        card.className = `account-card ${account.type}-card`;
        
        let cardContent = `
            <div class="account-type">${account.name}</div>
            <div class="account-balance">${formatCurrency(account.balance)}</div>
            <div class="account-number">Account ${account.accountNumber}</div>
        `;
        
        if (account.type === 'credit') {
            const usagePercent = (account.balance / account.creditLimit) * 100;
            cardContent += `
                <div class="credit-usage">
                    <div class="credit-usage-label">Available Credit: ${formatCurrency(account.creditLimit - account.balance)}</div>
                    <div class="credit-usage-bar">
                        <div class="credit-usage-fill" style="width: ${Math.min(usagePercent, 100)}%"></div>
                    </div>
                </div>
            `;
        }
        
        card.innerHTML = cardContent;
        container.appendChild(card);
    });
}

// Transfers
function loadTransfers() {
    populateAccountSelects();
}

function populateAccountSelects() {
    const selects = [
        'fromAccount', 'toAccount', 'quickFromAccount', 'quickToAccount',
        'paymentFromAccount', 'depositToAccount'
    ];
    
    selects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (select) {
            select.innerHTML = '<option value="">Select Account</option>';
            accounts.forEach(account => {
                const option = document.createElement('option');
                option.value = account.id;
                option.textContent = `${account.name} (${account.accountNumber}) - ${formatCurrency(account.balance)}`;
                select.appendChild(option);
            });
        }
    });
}

// Payments
function loadPayments() {
    populateAccountSelects();
    
    // Set default due date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById('paymentDueDate').value = tomorrow.toISOString().split('T')[0];
}

// Analytics
function loadAnalytics() {
    drawBalanceChart();
    drawSpendingChart();
}

function drawBalanceChart() {
    const canvas = document.getElementById('balanceChart');
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Chart data
    const data = accounts.map(account => ({
        label: account.name,
        value: account.balance,
        color: getAccountColor(account.type)
    }));
    
    // Simple bar chart
    const padding = 40;
    const chartWidth = canvas.width - padding * 2;
    const chartHeight = canvas.height - padding * 2;
    const barWidth = chartWidth / data.length - 20;
    const maxValue = Math.max(...data.map(d => d.value));
    
    data.forEach((item, index) => {
        const barHeight = (item.value / maxValue) * chartHeight;
        const x = padding + index * (barWidth + 20);
        const y = canvas.height - padding - barHeight;
        
        // Draw bar
        ctx.fillStyle = item.color;
        ctx.fillRect(x, y, barWidth, barHeight);
        
        // Draw label
        ctx.fillStyle = '#374151';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(item.label, x + barWidth / 2, canvas.height - 10);
        
        // Draw value
        ctx.fillText(formatCurrency(item.value), x + barWidth / 2, y - 5);
    });
}

function drawSpendingChart() {
    const canvas = document.getElementById('spendingChart');
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Sample spending data
    const months = ['Oct', 'Nov', 'Dec', 'Jan'];
    const spending = [8500, 9200, 7800, 8900];
    
    const padding = 40;
    const chartWidth = canvas.width - padding * 2;
    const chartHeight = canvas.height - padding * 2;
    const pointSpacing = chartWidth / (months.length - 1);
    const maxSpending = Math.max(...spending);
    
    // Draw line
    ctx.beginPath();
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 2;
    
    spending.forEach((value, index) => {
        const x = padding + index * pointSpacing;
        const y = canvas.height - padding - (value / maxSpending) * chartHeight;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
        
        // Draw point
        ctx.fillStyle = '#3b82f6';
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
        
        // Draw labels
        ctx.fillStyle = '#374151';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(months[index], x, canvas.height - 10);
        ctx.fillText(formatCurrency(value), x, y - 10);
    });
    
    ctx.stroke();
}

function getAccountColor(type) {
    const colors = {
        checking: '#3b82f6',
        savings: '#10b981',
        credit: '#f59e0b'
    };
    return colors[type] || '#6b7280';
}

// Modal functions
function openTransferModal() {
    populateAccountSelects();
    document.getElementById('transferModal').style.display = 'block';
}

function openPaymentModal() {
    document.getElementById('paymentModal').style.display = 'block';
}

function openDepositModal() {
    populateAccountSelects();
    document.getElementById('depositModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Form handlers
function handleTransfer(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const fromAccountId = formData.get('fromAccount') || document.getElementById('quickFromAccount').value;
    const toAccountId = formData.get('toAccount') || document.getElementById('quickToAccount').value;
    const amount = parseFloat(formData.get('amount') || document.getElementById('quickTransferAmount').value);
    
    if (fromAccountId && toAccountId && amount > 0) {
        // Update account balances
        const fromAccount = accounts.find(a => a.id === fromAccountId);
        const toAccount = accounts.find(a => a.id === toAccountId);
        
        if (fromAccount.balance >= amount) {
            fromAccount.balance -= amount;
            toAccount.balance += amount;
            
            // Add transactions
            transactions.unshift({
                id: Date.now().toString(),
                accountId: fromAccountId,
                type: 'debit',
                amount: amount,
                description: `Transfer to ${toAccount.name}`,
                date: new Date().toISOString().split('T')[0],
                category: 'Transfer'
            });
            
            transactions.unshift({
                id: (Date.now() + 1).toString(),
                accountId: toAccountId,
                type: 'credit',
                amount: amount,
                description: `Transfer from ${fromAccount.name}`,
                date: new Date().toISOString().split('T')[0],
                category: 'Transfer'
            });
            
            alert('Transfer completed successfully!');
            event.target.reset();
            closeModal('transferModal');
            loadDashboard();
        } else {
            alert('Insufficient funds!');
        }
    }
}

function handlePayment(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const payee = formData.get('payee') || document.getElementById('quickPayeeName').value;
    const amount = parseFloat(formData.get('amount') || document.getElementById('quickPaymentAmount').value);
    const fromAccountId = formData.get('fromAccount') || document.getElementById('paymentFromAccount').value;
    
    if (payee && amount > 0 && fromAccountId) {
        const fromAccount = accounts.find(a => a.id === fromAccountId);
        
        if (fromAccount.balance >= amount) {
            fromAccount.balance -= amount;
            
            transactions.unshift({
                id: Date.now().toString(),
                accountId: fromAccountId,
                type: 'debit',
                amount: amount,
                description: `Payment to ${payee}`,
                date: new Date().toISOString().split('T')[0],
                category: 'Payment'
            });
            
            alert('Payment completed successfully!');
            event.target.reset();
            closeModal('paymentModal');
            loadDashboard();
        } else {
            alert('Insufficient funds!');
        }
    }
}

function handleDeposit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const amount = parseFloat(formData.get('amount'));
    const toAccountId = formData.get('toAccount');
    
    if (amount > 0 && toAccountId) {
        const toAccount = accounts.find(a => a.id === toAccountId);
        toAccount.balance += amount;
        
        transactions.unshift({
            id: Date.now().toString(),
            accountId: toAccountId,
            type: 'credit',
            amount: amount,
            description: 'Mobile Deposit',
            date: new Date().toISOString().split('T')[0],
            category: 'Deposit'
        });
        
        alert('Deposit completed successfully!');
        event.target.reset();
        closeModal('depositModal');
        loadDashboard();
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication on page load
    checkAuth();
    
    // Login form
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (login(username, password)) {
            // Login successful
        } else {
            alert('Invalid credentials. Use demo/demo to login.');
        }
    });
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', logout);
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            showPage(page);
        });
    });
    
    // Forms
    document.getElementById('transferForm').addEventListener('submit', handleTransfer);
    document.getElementById('quickTransferForm').addEventListener('submit', handleTransfer);
    document.getElementById('paymentForm').addEventListener('submit', handlePayment);
    document.getElementById('quickPaymentForm').addEventListener('submit', handlePayment);
    document.getElementById('depositForm').addEventListener('submit', handleDeposit);
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
});
