import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertTransferSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // In a real app, you'd use proper session management
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    res.json({ message: "Logged out successfully" });
  });

  // Account routes
  app.get("/api/accounts", async (req, res) => {
    const userId = req.query.userId as string;
    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const accounts = await storage.getAccountsByUserId(userId);
    res.json(accounts);
  });

  app.get("/api/accounts/:id", async (req, res) => {
    const account = await storage.getAccount(req.params.id);
    if (!account) {
      return res.status(404).json({ message: "Account not found" });
    }
    res.json(account);
  });

  // Transaction routes
  app.get("/api/transactions", async (req, res) => {
    const userId = req.query.userId as string;
    const accountId = req.query.accountId as string;

    if (accountId) {
      const transactions = await storage.getTransactionsByAccountId(accountId);
      res.json(transactions);
    } else if (userId) {
      const transactions = await storage.getTransactionsByUserId(userId);
      res.json(transactions);
    } else {
      res.status(400).json({ message: "User ID or Account ID is required" });
    }
  });

  // Transfer routes
  app.post("/api/transfers", async (req, res) => {
    try {
      console.log("Transfer request body:", req.body);
      const transferData = insertTransferSchema.parse(req.body);
      console.log("Parsed transfer data:", transferData);
      
      // Validate accounts exist
      const fromAccount = await storage.getAccount(transferData.fromAccountId);
      const toAccount = await storage.getAccount(transferData.toAccountId);
      
      console.log("From account lookup result:", fromAccount ? `Found: ${fromAccount.name}` : "NOT FOUND");
      console.log("To account lookup result:", toAccount ? `Found: ${toAccount.name}` : "NOT FOUND");
      
      if (!fromAccount) {
        return res.status(404).json({ message: `From account not found: ${transferData.fromAccountId}` });
      }
      
      if (!toAccount) {
        return res.status(404).json({ message: `To account not found: ${transferData.toAccountId}` });
      }

      // Check sufficient balance (for non-credit accounts)
      if (fromAccount.type !== 'credit') {
        const currentBalance = parseFloat(fromAccount.balance);
        const transferAmount = parseFloat(transferData.amount);
        
        if (currentBalance < transferAmount) {
          return res.status(400).json({ message: "Insufficient funds" });
        }
      }

      // Create the transfer
      const transfer = await storage.createTransfer(transferData);

      // Update account balances
      const fromBalance = parseFloat(fromAccount.balance) - parseFloat(transferData.amount);
      const toBalance = parseFloat(toAccount.balance) + parseFloat(transferData.amount);

      await storage.updateAccountBalance(fromAccount.id, fromBalance.toString());
      await storage.updateAccountBalance(toAccount.id, toBalance.toString());

      // Create transaction records
      await storage.createTransaction({
        accountId: fromAccount.id,
        description: `Transfer to ${toAccount.name}`,
        amount: `-${transferData.amount}`,
        type: "debit",
        status: "completed",
        reference: `Transfer ID: ${transfer.id}`,
      });

      await storage.createTransaction({
        accountId: toAccount.id,
        description: `Transfer from ${fromAccount.name}`,
        amount: transferData.amount,
        type: "credit",
        status: "completed",
        reference: `Transfer ID: ${transfer.id}`,
      });

      res.json(transfer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid transfer data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/transfers", async (req, res) => {
    const userId = req.query.userId as string;
    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const transfers = await storage.getTransfersByUserId(userId);
    res.json(transfers);
  });

  const httpServer = createServer(app);
  return httpServer;
}
