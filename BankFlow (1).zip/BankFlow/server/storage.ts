import { type User, type InsertUser, type Account, type InsertAccount, type Transaction, type InsertTransaction, type Transfer, type InsertTransfer } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Account methods
  getAccountsByUserId(userId: string): Promise<Account[]>;
  getAccount(id: string): Promise<Account | undefined>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccountBalance(id: string, balance: string): Promise<Account | undefined>;

  // Transaction methods
  getTransactionsByAccountId(accountId: string): Promise<Transaction[]>;
  getTransactionsByUserId(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Transfer methods
  createTransfer(transfer: InsertTransfer): Promise<Transfer>;
  getTransfersByUserId(userId: string): Promise<Transfer[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private accounts: Map<string, Account>;
  private transactions: Map<string, Transaction>;
  private transfers: Map<string, Transfer>;

  constructor() {
    this.users = new Map();
    this.accounts = new Map();
    this.transactions = new Map();
    this.transfers = new Map();
    this.seedData();
  }

  private seedData() {
    // Create Christina's user with fixed ID
    const userId = '1'; // Fixed ID to match frontend
    const user: User = {
      id: userId,
      username: "Christukes007",
      password: "Mrspeacemaker0098",
      name: "Christina Mary Tukes",
      email: "ctukes4@gmail.com",
      avatar: '/attached_assets/4f25c1de-ce2e-4cb2-83ba-6183e35565a6_1754258509924.jpeg',
      createdAt: new Date(),
    };
    this.users.set(userId, user);

    // Create demo accounts with consistent IDs
    const checkingAccount: Account = {
      id: "1", // Fixed ID to match frontend
      userId,
      name: "Business Checking",
      type: "checking",
      accountNumber: "••••0986",
      routingNumber: "111925113",
      balance: "2847392.18",
      availableCredit: null,
      creditLimit: null,
      isActive: true,
      createdAt: new Date(),
    };

    const savingsAccount: Account = {
      id: "2", // Fixed ID to match frontend
      userId,
      name: "Business Savings",
      type: "savings",
      accountNumber: "••••9789",
      routingNumber: "111925113",
      balance: "5628750.00",
      availableCredit: null,
      creditLimit: null,
      isActive: true,
      createdAt: new Date(),
    };

    const creditAccount: Account = {
      id: "3", // Fixed ID to match frontend
      userId,
      name: "Credit Line",
      type: "credit",
      accountNumber: "••••9012",
      routingNumber: "111925113",
      balance: "1426750.00",
      availableCredit: "3573250.00",
      creditLimit: "5000000.00",
      isActive: true,
      createdAt: new Date(),
    };

    this.accounts.set(checkingAccount.id, checkingAccount);
    this.accounts.set(savingsAccount.id, savingsAccount);
    this.accounts.set(creditAccount.id, creditAccount);

    // Create demo transactions
    const transactions: Transaction[] = [
      // July 2025 transactions
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Direct Deposit - Client Payment",
        amount: "2150000.00",
        type: "credit",
        status: "completed",
        reference: "Enterprise Solutions Inc",
        date: new Date("2025-07-15"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "International Wire Transfer",
        amount: "-750000.00",
        type: "debit",
        status: "completed",
        reference: "To: Global Manufacturing Ltd",
        date: new Date("2025-07-12"),
      },
      {
        id: randomUUID(),
        accountId: "3", // creditAccount.id
        description: "Equipment Purchase",
        amount: "-420000.00",
        type: "debit",
        status: "completed",
        reference: "Tech Equipment Corp - Invoice #INV-2025-007",
        date: new Date("2025-07-08"),
      },
      // June 2025 transactions
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Payroll Processing",
        amount: "-890000.00",
        type: "debit",
        status: "completed",
        reference: "June 2025 Payroll",
        date: new Date("2025-06-28"),
      },
      {
        id: randomUUID(),
        accountId: "2", // savingsAccount.id
        description: "Quarterly Interest Payment",
        amount: "35750.00",
        type: "credit",
        status: "completed",
        reference: "Q2 2025 Interest",
        date: new Date("2025-06-30"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Mobile Deposit",
        amount: "185000.00",
        type: "credit",
        status: "completed",
        reference: "Check #5892 - Client Payment",
        date: new Date("2025-06-25"),
      },
      // May 2025 transactions
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "ACH Return - NSF",
        amount: "-25000.00",
        type: "debit",
        status: "failed",
        reference: "Returned Payment - Insufficient Funds",
        date: new Date("2025-05-22"),
      },
      {
        id: randomUUID(),
        accountId: "2", // savingsAccount.id
        description: "Transfer from Checking",
        amount: "1200000.00",
        type: "credit",
        status: "completed",
        reference: "Internal Transfer",
        date: new Date("2025-05-18"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Transfer to Savings",
        amount: "-1200000.00",
        type: "debit",
        status: "completed",
        reference: "Internal Transfer",
        date: new Date("2025-05-18"),
      },
      {
        id: randomUUID(),
        accountId: "3", // creditAccount.id
        description: "Credit Line Payment",
        amount: "350000.00",
        type: "credit",
        status: "completed",
        reference: "Monthly Payment",
        date: new Date("2025-05-15"),
      },
      // April 2025 transactions
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Contractor Payment",
        amount: "-650000.00",
        type: "debit",
        status: "completed",
        reference: "Construction Services LLC",
        date: new Date("2025-04-30"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Customer Invoice Payment",
        amount: "1850000.00",
        type: "credit",
        status: "completed",
        reference: "Fortune 500 Client - Project Alpha",
        date: new Date("2025-04-28"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Office Lease Payment",
        amount: "-125000.00",
        type: "debit",
        status: "completed",
        reference: "Premium Office Complex - Q2 2025",
        date: new Date("2025-04-15"),
      },
      {
        id: randomUUID(),
        accountId: "2", // savingsAccount.id
        description: "Investment Dividend",
        amount: "45000.00",
        type: "credit",
        status: "completed",
        reference: "Corporate Bond Portfolio",
        date: new Date("2025-04-10"),
      },
      {
        id: randomUUID(),
        accountId: "1", // checkingAccount.id
        description: "Tax Payment",
        amount: "-425000.00",
        type: "debit",
        status: "completed",
        reference: "Q1 2025 Estimated Taxes",
        date: new Date("2025-04-15"),
      },
    ];

    transactions.forEach(transaction => {
      this.transactions.set(transaction.id, transaction);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async getAccountsByUserId(userId: string): Promise<Account[]> {
    return Array.from(this.accounts.values()).filter(
      (account) => account.userId === userId,
    );
  }

  async getAccount(id: string): Promise<Account | undefined> {
    return this.accounts.get(id);
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const id = randomUUID();
    const account: Account = { ...insertAccount, id, createdAt: new Date() };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccountBalance(id: string, balance: string): Promise<Account | undefined> {
    const account = this.accounts.get(id);
    if (account) {
      account.balance = balance;
      this.accounts.set(id, account);
    }
    return account;
  }

  async getTransactionsByAccountId(accountId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.accountId === accountId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getTransactionsByUserId(userId: string): Promise<Transaction[]> {
    const userAccounts = await this.getAccountsByUserId(userId);
    const accountIds = userAccounts.map(account => account.id);

    return Array.from(this.transactions.values())
      .filter((transaction) => accountIds.includes(transaction.accountId))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = { ...insertTransaction, id, date: new Date() };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async createTransfer(insertTransfer: InsertTransfer): Promise<Transfer> {
    const id = randomUUID();
    const transfer: Transfer = { ...insertTransfer, id, createdAt: new Date() };
    this.transfers.set(id, transfer);
    return transfer;
  }

  async getTransfersByUserId(userId: string): Promise<Transfer[]> {
    const userAccounts = await this.getAccountsByUserId(userId);
    const accountIds = userAccounts.map(account => account.id);

    return Array.from(this.transfers.values())
      .filter((transfer) => 
        accountIds.includes(transfer.fromAccountId) || 
        accountIds.includes(transfer.toAccountId)
      )
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}

export const storage = new MemStorage();