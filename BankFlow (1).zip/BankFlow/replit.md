# Business Banking Application

## Overview

This is a modern business banking web application built as a prototype inspired by Harmony's design and user experience. The application provides a comprehensive suite of banking features including account management, transaction tracking, fund transfers, and financial analytics. It features a professional, enterprise-grade interface with a responsive design that works across desktop and mobile devices.

The application uses a full-stack TypeScript architecture with React on the frontend and Express.js on the backend, providing type safety throughout the entire stack. The UI follows modern design principles with shadcn/ui components and Tailwind CSS for styling.

## User Preferences

Preferred communication style: Simple, everyday language.
Mobile-first design: App should be optimized for mobile phones with touch-friendly interactions.

## System Architecture

### Frontend Architecture

The frontend is built using React with TypeScript and follows a component-based architecture. Key architectural decisions include:

- **Component Library**: Uses shadcn/ui components built on top of Radix UI primitives for accessibility and consistency
- **Styling**: Tailwind CSS with custom banking-specific color variables and responsive design patterns
- **State Management**: React Context for authentication state, React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas

The application structure separates concerns into:
- **Layout Components**: Sidebar navigation, top bar, and main layout wrapper
- **Feature Components**: Account cards, transaction tables, transfer modals, charts
- **UI Components**: Reusable shadcn/ui components for buttons, cards, dialogs, etc.
- **Pages**: Route-level components for dashboard, accounts, transfers, payments, and analytics

### Backend Architecture

The backend uses Express.js with TypeScript and implements a RESTful API design:

- **API Structure**: Organized into logical route groups (auth, accounts, transactions, transfers)
- **Data Layer**: In-memory storage implementation with interface abstraction for future database integration
- **Schema Validation**: Zod schemas shared between client and server for type safety
- **Middleware**: Request logging and error handling middleware

The server provides endpoints for:
- Authentication (login/logout)
- Account management and balance retrieval
- Transaction history and creation
- Fund transfers between accounts

### Data Storage

Currently uses an in-memory storage implementation with seeded demo data:

- **Storage Interface**: Abstracted storage interface (IStorage) allows for easy migration to persistent databases
- **Demo Data**: Pre-populated with realistic business banking data including users, accounts, and transactions
- **Database Schema**: Drizzle ORM schema definitions prepared for PostgreSQL migration

The schema includes:
- Users table with authentication credentials
- Accounts table supporting checking, savings, and credit account types
- Transactions table with comprehensive transaction tracking
- Transfers table for internal fund movements

### Authentication and Authorization

Implements a simple session-based authentication system:

- **Login Flow**: Username/password authentication with manual credential entry (no autofill)
- **Session Management**: Client-side storage using localStorage for prototype purposes
- **Protected Routes**: Route-level protection using React Context
- **User State**: Global user state management through AuthContext

### Mobile Optimization (Added 2025-08-08)

Comprehensive mobile-first design implementation:

- **Touch-Friendly Interface**: 44px minimum touch targets for buttons and interactive elements
- **Responsive Typography**: Mobile-optimized text sizes that scale appropriately across devices
- **Mobile Layout**: Flexible layouts that stack vertically on small screens and expand on larger ones
- **Form Optimization**: Enhanced input fields with proper sizing to prevent iOS zoom and better UX
- **Navigation**: Mobile-optimized sidebar with overlay and improved touch navigation
- **Account Management**: Updated account numbers (Checking: ••••0986, Savings: ••••9789)
- **CSS Utilities**: Custom mobile utility classes for consistent spacing, grids, and touch interactions

## External Dependencies

### UI and Styling Dependencies
- **shadcn/ui**: Modern component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Radix UI**: Accessible component primitives for complex UI elements
- **Lucide React**: Icon library with consistent design language

### Data and State Management
- **React Query (@tanstack/react-query)**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation for type-safe data handling
- **Drizzle ORM**: Type-safe database ORM (prepared for PostgreSQL)

### Charts and Visualization
- **Recharts**: React charting library for financial data visualization
- **Embla Carousel**: Lightweight carousel component

### Database and Storage
- **Neon Database (@neondatabase/serverless)**: Serverless PostgreSQL database (configured but not yet implemented)
- **Drizzle Kit**: Database migration and schema management tool

### Development and Build Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast JavaScript bundler for production builds

### Routing and Navigation
- **Wouter**: Lightweight client-side routing library

The application is designed to be easily deployable to platforms like Vercel or similar hosting providers, with the database migration path already prepared for moving from in-memory storage to PostgreSQL.