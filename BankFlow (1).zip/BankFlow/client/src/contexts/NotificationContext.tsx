import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import type { Transaction } from "@shared/schema";

export interface Notification {
  id: string;
  type: 'transaction' | 'transfer' | 'payment' | 'alert' | 'system';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  amount?: string;
  accountName?: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Fetch recent transactions to generate notifications
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions", user?.id],
    enabled: !!user?.id,
    refetchInterval: 30000, // Refetch every 30 seconds for new transactions
  });

  // Generate notifications from transactions and system messages
  useEffect(() => {
    if (!transactions.length) return;

    const newNotifications: Notification[] = [];

    // Add transaction notifications
    transactions.forEach((transaction, index) => {
      const isCredit = parseFloat(transaction.amount) > 0;
      const notificationType = isCredit ? 'transaction' : 'payment';
      
      newNotifications.push({
        id: `txn-${transaction.id}`,
        type: notificationType,
        title: isCredit ? 'Payment Received' : 'Payment Processed',
        message: `${transaction.description} - $${Math.abs(parseFloat(transaction.amount)).toLocaleString()}`,
        timestamp: transaction.date ? new Date(transaction.date) : new Date(),
        read: false,
        amount: transaction.amount,
        accountName: transaction.accountId === '1' ? 'Business Checking' : 'Business Savings'
      });
    });

    // Add system notifications with dates that match transaction timeline
    if (transactions.length > 0) {
      const latestTransactionDate = new Date(Math.max(...transactions.map(t => t.date ? new Date(t.date).getTime() : 0)));
      
      newNotifications.push({
        id: 'system-1',
        type: 'system',
        title: 'Account Security Update',
        message: 'Your account security settings have been updated successfully',
        timestamp: new Date(latestTransactionDate.getTime() + 30 * 60 * 1000), // 30 minutes after latest transaction
        read: false
      });

      // Find the largest credit transaction for alert
      const largestCredit = transactions
        .filter(t => parseFloat(t.amount) > 0)
        .sort((a, b) => parseFloat(b.amount) - parseFloat(a.amount))[0];

      if (largestCredit && parseFloat(largestCredit.amount) > 10000) {
        newNotifications.push({
          id: 'alert-1',
          type: 'alert',
          title: 'Large Transaction Alert',
          message: `A large transaction of $${parseFloat(largestCredit.amount).toLocaleString()} has been processed on your ${largestCredit.accountId === '1' ? 'checking' : 'savings'} account`,
          timestamp: new Date((largestCredit.date ? new Date(largestCredit.date) : new Date()).getTime() + 5 * 60 * 1000), // 5 minutes after transaction
          read: false,
          amount: largestCredit.amount,
          accountName: largestCredit.accountId === '1' ? 'Business Checking' : 'Business Savings'
        });
      }
    }

    // Sort by timestamp (newest first)
    newNotifications.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    setNotifications(newNotifications);
  }, [transactions]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `custom-${Date.now()}`,
      timestamp: new Date(),
      read: false
    };

    setNotifications(prev => [newNotification, ...prev]);
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      markAsRead,
      markAllAsRead,
      addNotification
    }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}