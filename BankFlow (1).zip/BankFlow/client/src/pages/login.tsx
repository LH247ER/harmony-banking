import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, isLoading } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(username, password);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Invalid username or password",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 mobile-padding py-8">
      <Card className="w-full max-w-md mx-auto card-backdrop">
        <CardHeader className="text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center">
              <img src="/logo-accent.svg" alt="Harmony" className="w-12 h-12 sm:w-16 sm:h-16" />
            </div>
          </div>
          <CardTitle className="mobile-text-balance font-semibold text-readable">Welcome to Harmony</CardTitle>
          <CardDescription className="text-sm sm:text-base text-readable">Sign in to your business banking account</CardDescription>
        </CardHeader>
        <CardContent className="p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-5 sm:space-y-6" autoComplete="off">
            <div className="space-y-2">
              <Label htmlFor="username" className="mobile-text-label">Username</Label>
              <Input
                id="username"
                name="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
                spellCheck="false"
                className="touch-target py-3 text-base"
                data-testid="input-username"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="mobile-text-label">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                autoComplete="new-password"
                className="touch-target py-3 text-base"
                data-testid="input-password"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full touch-target py-3 sm:py-2 bg-blue-600 hover:bg-blue-700 text-base font-medium"
              disabled={isLoading}
              data-testid="button-login"
            >
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>
          
        </CardContent>
      </Card>
    </div>
  );
}
