import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import TransferModal from "@/components/TransferModal";
import { formatCurrency, formatDate } from "@/utils/formatters";

export default function Transfers() {
  const { user } = useAuth();
  const [transferModalOpen, setTransferModalOpen] = useState(false);

  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
    queryFn: async () => {
      const response = await fetch(`/api/accounts?userId=${user?.id}`);
      if (!response.ok) throw new Error("Failed to fetch accounts");
      return response.json();
    },
    enabled: !!user?.id,
  });

  const { data: transfers = [], isLoading } = useQuery({
    queryKey: ["/api/transfers"],
    queryFn: async () => {
      const response = await fetch(`/api/transfers?userId=${user?.id}`);
      if (!response.ok) throw new Error("Failed to fetch transfers");
      return response.json();
    },
    enabled: !!user?.id,
  });

  const getAccountName = (accountId: string) => {
    const account = accounts.find(acc => acc.id === accountId);
    return account?.name || "Unknown Account";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-slate-200 rounded w-1/4"></div>
        </div>
        <div className="animate-pulse">
          <div className="h-32 bg-slate-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-readable">Transfers</h1>
          <p className="mt-1 text-sm text-slate-600">
            Transfer money between accounts
          </p>
        </div>
        <Button 
          onClick={() => setTransferModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          New Transfer
        </Button>
      </div>

      <Card className="card-backdrop">
        <CardHeader>
          <CardTitle>Recent Transfers</CardTitle>
        </CardHeader>
        <CardContent>
          {transfers.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500">No transfers found</p>
              <Button 
                onClick={() => setTransferModalOpen(true)}
                className="mt-4 bg-blue-600 hover:bg-blue-700"
              >
                Make your first transfer
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {transfers.map((transfer) => (
                <div 
                  key={transfer.id} 
                  className="flex items-center justify-between p-4 border border-slate-200 rounded-lg"
                >
                  <div>
                    <p className="font-medium text-readable">
                      {getAccountName(transfer.fromAccountId)} → {getAccountName(transfer.toAccountId)}
                    </p>
                    <p className="text-sm text-slate-500">
                      {formatDate(transfer.createdAt)}
                    </p>
                    {transfer.description && (
                      <p className="text-sm text-slate-600">{transfer.description}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-readable">
                      {formatCurrency(transfer.amount)}
                    </p>
                    <p className="text-sm text-green-600 capitalize">
                      {transfer.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <TransferModal
        isOpen={transferModalOpen}
        onClose={() => setTransferModalOpen(false)}
        accounts={accounts}
      />
    </div>
  );
}