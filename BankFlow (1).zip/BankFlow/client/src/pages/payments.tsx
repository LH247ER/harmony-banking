import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Receipt, Calendar, CreditCard } from "lucide-react";
import BillPaymentModal from "@/components/BillPaymentModal";
import { Account } from "@shared/schema";

export default function Payments() {
  const { user } = useAuth();
  const [billPayModalOpen, setBillPayModalOpen] = useState(false);
  const [schedulePayModalOpen, setSchedulePayModalOpen] = useState(false);

  const { data: accounts = [] } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
    queryFn: async () => {
      const response = await fetch(`/api/accounts?userId=${user?.id}`);
      if (!response.ok) throw new Error("Failed to fetch accounts");
      return response.json();
    },
    enabled: !!user?.id,
  });

  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Bills & Payments</h1>
          <p className="mt-1 text-sm text-slate-600">
            Manage your business payments and scheduled bills
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="banking-card-hover">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Receipt className="w-5 h-5 text-blue-600" />
                </div>
                <div className="ml-4">
                  <h3 className="text-sm font-medium text-slate-900">Pay Bills</h3>
                  <p className="text-xs text-slate-500">One-time payments</p>
                </div>
              </div>
              <Button 
                className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                onClick={() => setBillPayModalOpen(true)}
              >
                Pay a Bill
              </Button>
            </CardContent>
          </Card>

          <Card className="banking-card-hover">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-green-600" />
                </div>
                <div className="ml-4">
                  <h3 className="text-sm font-medium text-slate-900">Schedule Payments</h3>
                  <p className="text-xs text-slate-500">Recurring or future payments</p>
                </div>
              </div>
              <Button 
                className="w-full mt-4 bg-green-600 hover:bg-green-700"
                onClick={() => setSchedulePayModalOpen(true)}
              >
                Schedule Payment
              </Button>
            </CardContent>
          </Card>

          <Card className="banking-card-hover">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-purple-600" />
                </div>
                <div className="ml-4">
                  <h3 className="text-sm font-medium text-slate-900">Payees</h3>
                  <p className="text-xs text-slate-500">Manage payment recipients</p>
                </div>
              </div>
              <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
                Manage Payees
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <p className="text-slate-500">No recent payments</p>
              <p className="text-sm text-slate-400 mt-2">
                Your payment history will appear here
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <BillPaymentModal
        isOpen={billPayModalOpen}
        onClose={() => setBillPayModalOpen(false)}
        accounts={accounts}
      />

      <BillPaymentModal
        isOpen={schedulePayModalOpen}
        onClose={() => setSchedulePayModalOpen(false)}
        accounts={accounts}
      />
    </>
  );
}