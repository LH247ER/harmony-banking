import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import AccountDetailsModal from "@/components/AccountDetailsModal";
import { formatCurrency } from "@/utils/formatters";
import { Account } from "@shared/schema";

export default function Accounts() {
  const { user } = useAuth();
  const [accountDetailsModalOpen, setAccountDetailsModalOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ["/api/accounts"],
    queryFn: async () => {
      // Always use mock data for Christina
      if (user?.username === "Christukes007") {
        return [
          {
            id: '1',
            name: 'Business Checking',
            type: 'checking',
            balance: '2847392.18',
            accountNumber: '••••0986',
            routingNumber: '111925113',
            userId: user?.id || '1',
            isActive: true,
            availableCredit: null,
            creditLimit: null,
            createdAt: new Date()
          },
          {
            id: '2',
            name: 'Business Savings',
            type: 'savings',
            balance: '5628750.00',
            accountNumber: '••••9789',
            routingNumber: '111925113',
            userId: user?.id || '1',
            isActive: true,
            availableCredit: null,
            creditLimit: null,
            createdAt: new Date()
          },
          {
            id: '3',
            name: 'Credit Line',
            type: 'credit',
            balance: '1426750.00',
            accountNumber: '••••9012',
            routingNumber: '111925113',
            availableCredit: '3573250.00',
            creditLimit: '5000000.00',
            userId: user?.id || '1',
            isActive: true,
            createdAt: new Date()
          }
        ];
      }

      // For other users, try API
      const response = await fetch(`/api/accounts?userId=${user?.id}`);
      if (!response.ok) throw new Error("Failed to fetch accounts");
      return response.json();
    },
    enabled: !!user?.id,
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-slate-200 rounded w-1/4"></div>
        </div>
        <div className="grid gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="h-32 bg-slate-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="mobile-text-heading font-semibold text-slate-900">Accounts</h1>
        <p className="mt-1 text-sm sm:text-base text-slate-600">
          Manage your business banking accounts
        </p>
      </div>

      <div className="grid gap-4 sm:gap-6">
        {accounts.map((account) => (
          <Card key={account.id} className="banking-shadow card-backdrop">
            <CardHeader className="pb-3 sm:pb-6">
              <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <span className="mobile-text-label text-readable">{account.name}</span>
                <span className="mobile-text-balance font-semibold text-readable">
                  {formatCurrency(account.balance)}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 text-sm">
                <div>
                  <p className="text-slate-500 text-xs sm:text-sm">Account Number</p>
                  <p className="font-medium text-readable" data-testid={`text-account-number-${account.id}`}>{account.accountNumber}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-xs sm:text-sm">Account Type</p>
                  <p className="font-medium capitalize text-readable" data-testid={`text-account-type-${account.id}`}>{account.type}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-xs sm:text-sm">Status</p>
                  <p className="font-medium text-green-600" data-testid={`text-account-status-${account.id}`}>
                    {account.isActive ? "Active" : "Inactive"}
                  </p>
                </div>
                {account.type === "credit" && (
                  <div>
                    <p className="text-slate-500 text-xs sm:text-sm">Available Credit</p>
                    <p className="font-medium" data-testid={`text-available-credit-${account.id}`}>{formatCurrency(account.availableCredit || "0")}</p>
                  </div>
                )}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-200">
                <Button 
                  onClick={() => {
                    setSelectedAccount(account);
                    setAccountDetailsModalOpen(true);
                  }}
                  variant="outline"
                  className="w-full touch-target py-3 sm:py-2"
                  data-testid={`button-view-details-${account.id}`}
                >
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <AccountDetailsModal
        isOpen={accountDetailsModalOpen}
        onClose={() => {
          setAccountDetailsModalOpen(false);
          setSelectedAccount(null);
        }}
        account={selectedAccount}
      />
    </div>
  );
}
