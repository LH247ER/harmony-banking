import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import AccountCard from "@/components/AccountCard";
import TransactionTable from "@/components/TransactionTable";
import TransferModal from "@/components/TransferModal";
import BillPaymentModal from "@/components/BillPaymentModal";
import MobileDepositModal from "@/components/MobileDepositModal";
import StatementsModal from "@/components/StatementsModal";
import AccountDetailsModal from "@/components/AccountDetailsModal";
import CashFlowChart from "@/components/CashFlowChart";
import QuickActions from "@/components/QuickActions";
import { Account } from "@shared/schema";

// Mock Card component to apply the changes as per the instructions
// In a real application, this would be imported from a UI library like Shadcn UI
const Card = ({ children, className }) => {
  return <div className={className}>{children}</div>;
};

// Mock CardHeader component
const CardHeader = ({ children, className }) => {
  return <div className={className}>{children}</div>;
};

// Mock CardTitle component
const CardTitle = ({ children, className }) => {
  return <h2 className={className}>{children}</h2>;
};


export default function Dashboard() {
  const { user } = useAuth();
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [billPayModalOpen, setBillPayModalOpen] = useState(false);
  const [mobileDepositModalOpen, setMobileDepositModalOpen] = useState(false);
  const [statementsModalOpen, setStatementsModalOpen] = useState(false);
  const [accountDetailsModalOpen, setAccountDetailsModalOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);

  const { data: accounts = [], isLoading: accountsLoading } = useQuery({
    queryKey: ["/api/accounts"],
    queryFn: async () => {
      // Always use mock data for Christina
      if (user?.username === "Christukes007") {
        return [
          {
            id: '1',
            name: 'Business Checking',
            type: 'checking',
            balance: '2847392.18',
            accountNumber: '••••0986',
            userId: user?.id || '1',
            isActive: true,
            createdAt: new Date()
          },
          {
            id: '2',
            name: 'Business Savings',
            type: 'savings',
            balance: '5628750.00',
            accountNumber: '••••9789',
            userId: user?.id || '1',
            isActive: true,
            createdAt: new Date()
          },
          {
            id: '3',
            name: 'Credit Line',
            type: 'credit',
            balance: '1426750.00',
            accountNumber: '••••9012',
            availableCredit: '3573250.00',
            creditLimit: '5000000.00',
            userId: user?.id || '1',
            isActive: true,
            createdAt: new Date()
          }
        ];
      }

      // For other users, try API
      try {
        const response = await fetch(`/api/accounts?userId=${user?.id}`);
        if (!response.ok) throw new Error("Failed to fetch accounts");
        return response.json();
      } catch (error) {
        console.warn("API failed, using fallback data:", error);
        return [];
      }
    },
    enabled: !!user?.id,
  });

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/transactions"],
    queryFn: async () => {
      // Always use mock data for Christina
      if (user?.username === "Christukes007") {
        return [
          {
            id: '1',
            accountId: '1',
            description: 'Direct Deposit - Client Payment',
            amount: '2150000.00',
            type: 'credit',
            status: 'completed',
            reference: 'Enterprise Solutions Inc',
            date: new Date('2025-07-15')
          },
          {
            id: '2',
            accountId: '1',
            description: 'International Wire Transfer',
            amount: '-750000.00',
            type: 'debit',
            status: 'completed',
            reference: 'To: Global Manufacturing Ltd',
            date: new Date('2025-07-12')
          },
          {
            id: '3',
            accountId: '3',
            description: 'Equipment Purchase',
            amount: '-420000.00',
            type: 'debit',
            status: 'completed',
            reference: 'Tech Equipment Corp - Invoice #INV-2025-007',
            date: new Date('2025-07-08')
          },
          {
            id: '4',
            accountId: '1',
            description: 'Payroll Processing',
            amount: '-890000.00',
            type: 'debit',
            status: 'completed',
            reference: 'June 2025 Payroll',
            date: new Date('2025-06-28')
          },
          {
            id: '5',
            accountId: '2',
            description: 'Quarterly Interest Payment',
            amount: '35750.00',
            type: 'credit',
            status: 'completed',
            reference: 'Q2 2025 Interest',
            date: new Date('2025-06-30')
          }
        ];
      }

      // For other users, try API
      try {
        const response = await fetch(`/api/transactions?userId=${user?.id}`);
        if (!response.ok) throw new Error("Failed to fetch transactions");
        return response.json();
      } catch (error) {
        console.warn("API failed, using fallback data:", error);
        return [];
      }
    },
    enabled: !!user?.id,
  });

  if (accountsLoading || transactionsLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-slate-200 rounded w-1/3 mb-2"></div>
          <div className="h-4 bg-slate-200 rounded w-1/2"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="h-48 bg-slate-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Page header */}
      <div className="mb-6 sm:mb-8">
        <h1 className="text-xl sm:text-2xl font-semibold text-slate-900">
          Welcome back, {user?.name}
        </h1>
        <p className="mt-1 text-sm sm:text-base text-slate-600">
          Here's what's happening with your business accounts today.
        </p>
      </div>

      {/* Account cards */}
      <div className="mobile-grid gap-4 sm:gap-6 mb-6 sm:mb-8">
        {accounts.map((account: Account) => (
          <AccountCard
            key={account.id}
            account={account}
            onTransfer={() => setTransferModalOpen(true)}
            onViewDetails={() => {
              setSelectedAccount(account);
              setAccountDetailsModalOpen(true);
            }}
          />
        ))}
      </div>

      {/* Charts and Quick Actions */}
      <div className="mobile-grid-2 gap-6 sm:gap-8 mb-6 sm:mb-8">
        {/* Applying changes to CashFlowChart conceptually as a card */}
        <div className="banking-card-hover card-backdrop">
          <CashFlowChart />
        </div>

        {/* Applying changes to QuickActions as a card */}
        <div className="banking-card-hover card-backdrop">
          <QuickActions
            onTransfer={() => setTransferModalOpen(true)}
            onBillPay={() => setBillPayModalOpen(true)}
            onMobileDeposit={() => setMobileDepositModalOpen(true)}
            onViewStatements={() => setStatementsModalOpen(true)}
          />
        </div>
      </div>

      {/* Recent Transactions */}
      {/* Applying changes to TransactionTable conceptually as a card */}
      <div className="banking-card-hover card-backdrop">
        <TransactionTable
          transactions={transactions.slice(0, 10)}
          accounts={accounts}
          isLoading={transactionsLoading}
        />
      </div>

      {/* Modals */}
      <TransferModal
        isOpen={transferModalOpen}
        onClose={() => setTransferModalOpen(false)}
        accounts={accounts}
      />

      <BillPaymentModal
        isOpen={billPayModalOpen}
        onClose={() => setBillPayModalOpen(false)}
        accounts={accounts}
      />

      <MobileDepositModal
        isOpen={mobileDepositModalOpen}
        onClose={() => setMobileDepositModalOpen(false)}
        accounts={accounts}
      />

      <StatementsModal
        isOpen={statementsModalOpen}
        onClose={() => setStatementsModalOpen(false)}
        accounts={accounts}
      />

      <AccountDetailsModal
        isOpen={accountDetailsModalOpen}
        onClose={() => {
          setAccountDetailsModalOpen(false);
          setSelectedAccount(null);
        }}
        account={selectedAccount}
      />
    </div>
  );
}