import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import CashFlowChart from "@/components/CashFlowChart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const mockMonthlyData = [
  { month: "Jul", income: 45000, expenses: 32000 },
  { month: "Aug", income: 52000, expenses: 38000 },
  { month: "Sep", income: 48000, expenses: 35000 },
  { month: "Oct", income: 55000, expenses: 42000 },
  { month: "Nov", income: 51000, expenses: 36000 },
  { month: "Dec", income: 58000, expenses: 44000 },
];

const mockExpenseData = [
  { name: "Payroll", value: 18000, color: "#3b82f6" },
  { name: "Rent", value: 8000, color: "#10b981" },
  { name: "Utilities", value: 3500, color: "#f59e0b" },
  { name: "Supplies", value: 4200, color: "#ef4444" },
  { name: "Marketing", value: 6800, color: "#8b5cf6" },
  { name: "Other", value: 3500, color: "#6b7280" },
];

export default function Analytics() {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">Analytics</h1>
        <p className="mt-1 text-sm text-slate-600">
          Financial insights and business performance metrics
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-sm font-medium text-slate-500">Total Revenue</div>
            <div className="text-2xl font-bold text-slate-900">$314,000</div>
            <div className="text-xs text-green-600">+12.5% from last period</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm font-medium text-slate-500">Total Expenses</div>
            <div className="text-2xl font-bold text-slate-900">$227,000</div>
            <div className="text-xs text-red-600">+8.2% from last period</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm font-medium text-slate-500">Net Profit</div>
            <div className="text-2xl font-bold text-slate-900">$87,000</div>
            <div className="text-xs text-green-600">+18.3% from last period</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-sm font-medium text-slate-500">Profit Margin</div>
            <div className="text-2xl font-bold text-slate-900">27.7%</div>
            <div className="text-xs text-green-600">+2.1% from last period</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <CashFlowChart />

        <Card>
          <CardHeader>
            <CardTitle>Monthly Income vs Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mockMonthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis
                    dataKey="month"
                    stroke="#64748b"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="#64748b"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={formatCurrency}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '6px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                    }}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Bar dataKey="income" fill="#3b82f6" radius={4} />
                  <Bar dataKey="expenses" fill="#ef4444" radius={4} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Expense Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={mockExpenseData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {mockExpenseData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {mockExpenseData.map((item, index) => (
                <div key={index} className="flex items-center text-sm">
                  <div
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-slate-600">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Key Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Average Daily Balance</span>
                <span className="font-semibold">$156,420</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Monthly Transaction Volume</span>
                <span className="font-semibold">$892,350</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Number of Transactions</span>
                <span className="font-semibold">342</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Average Transaction Size</span>
                <span className="font-semibold">$2,610</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Largest Single Transaction</span>
                <span className="font-semibold">$25,000</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Current Month Growth</span>
                <span className="font-semibold text-green-600">+15.2%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}