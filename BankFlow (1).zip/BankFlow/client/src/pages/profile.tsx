
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Mail, Phone, Building, MapPin } from "lucide-react";

export default function Profile() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-readable">Profile</h1>
        <p className="mt-1 text-sm text-readable">
          Manage your personal information and account details
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Picture Section */}
        <Card className="card-backdrop">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-readable">
              <User className="h-5 w-5" />
              Profile Picture
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <Avatar className="h-24 w-24">
              <AvatarImage src="/download.jpg" alt="Harmony Logo" />
              <AvatarFallback className="text-2xl">
                H
              </AvatarFallback>
            </Avatar>
            <Button variant="outline">Change Picture</Button>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card className="lg:col-span-2 card-backdrop">
          <CardHeader>
            <CardTitle className="text-readable">Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue="Christina Mary Tukes" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" defaultValue="ctukes4@gmail.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" defaultValue="+12147896987" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input id="dateOfBirth" defaultValue="04/12/1991" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="occupation">Occupation</Label>
                <Input id="occupation" defaultValue="Modelling" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="annualIncome">Annual Income</Label>
                <Input id="annualIncome" defaultValue="$160,000" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" defaultValue="135 Sims St Kingsland Texas, 78639" />
            </div>
            <div className="flex justify-end">
              <Button>Save Changes</Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="lg:col-span-3 card-backdrop">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-readable">
              <Mail className="h-5 w-5" />
              Contact Preferences
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h3 className="font-medium">Email Notifications</h3>
                <div className="space-y-2 text-sm">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" defaultChecked />
                    Transaction alerts
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" defaultChecked />
                    Account updates
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Marketing emails
                  </label>
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="font-medium">SMS Notifications</h3>
                <div className="space-y-2 text-sm">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" defaultChecked />
                    Security alerts
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Payment reminders
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Low balance alerts
                  </label>
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="font-medium">Security</h3>
                <div className="space-y-2">
                  <Button variant="outline" size="sm">Change Password</Button>
                  <Button variant="outline" size="sm">Enable 2FA</Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
