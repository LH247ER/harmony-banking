import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Camera, Upload } from "lucide-react";
import { Account } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface MobileDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
}

export default function MobileDepositModal({ isOpen, onClose, accounts }: MobileDepositModalProps) {
  const [accountId, setAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [checkNumber, setCheckNumber] = useState("");
  const [frontImage, setFrontImage] = useState<File | null>(null);
  const [backImage, setBackImage] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const depositMutation = useMutation({
    mutationFn: async (depositData: {
      accountId: string;
      description: string;
      amount: string;
      type: string;
      status: string;
      reference: string;
    }) => {
      const response = await apiRequest("POST", "/api/transactions", depositData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Check Deposited",
        description: "Your check deposit is being processed and will be available soon.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Deposit Failed",
        description: error.message || "An error occurred while processing the deposit.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!accountId || !amount || !checkNumber) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      });
      return;
    }

    // In a real app, you'd upload the check images here
    depositMutation.mutate({
      accountId,
      description: "Mobile Deposit",
      amount: depositAmount.toString(),
      type: "credit",
      status: "pending",
      reference: `Check #${checkNumber} - Mobile Deposit`,
    });
  };

  const handleClose = () => {
    setAccountId("");
    setAmount("");
    setCheckNumber("");
    setFrontImage(null);
    setBackImage(null);
    onClose();
  };

  const handleFileUpload = (file: File | null, side: 'front' | 'back') => {
    if (side === 'front') {
      setFrontImage(file);
    } else {
      setBackImage(file);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Camera className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <DialogTitle>Mobile Deposit</DialogTitle>
              <DialogDescription>Deposit a check using your mobile device</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="account">Deposit To Account</Label>
            <Select value={accountId} onValueChange={setAccountId}>
              <SelectTrigger>
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                {accounts.filter(acc => acc.type !== 'credit').map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    {account.name} ({account.accountNumber})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="checkNumber">Check Number</Label>
            <Input
              id="checkNumber"
              type="text"
              value={checkNumber}
              onChange={(e) => setCheckNumber(e.target.value)}
              placeholder="Enter check number"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Check Amount</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="pl-8"
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Front of Check</Label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center">
                <Camera className="mx-auto h-12 w-12 text-slate-400" />
                <div className="mt-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'image/*';
                      input.onchange = (e) => {
                        const file = (e.target as HTMLInputElement).files?.[0] || null;
                        handleFileUpload(file, 'front');
                      };
                      input.click();
                    }}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Front
                  </Button>
                </div>
                {frontImage && (
                  <p className="text-sm text-green-600 mt-2">✓ {frontImage.name}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Back of Check</Label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center">
                <Camera className="mx-auto h-12 w-12 text-slate-400" />
                <div className="mt-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'image/*';
                      input.onchange = (e) => {
                        const file = (e.target as HTMLInputElement).files?.[0] || null;
                        handleFileUpload(file, 'back');
                      };
                      input.click();
                    }}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Back
                  </Button>
                </div>
                {backImage && (
                  <p className="text-sm text-green-600 mt-2">✓ {backImage.name}</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-lg">
            <p className="text-sm text-slate-600">
              <strong>Important:</strong> Make sure the check is endorsed and the images are clear. 
              Deposits are typically available within 1-2 business days.
            </p>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={depositMutation.isPending}
            >
              {depositMutation.isPending ? "Processing..." : "Deposit Check"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}