import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, PiggyBank, CreditCard, TrendingUp } from "lucide-react";
import { Account } from "@shared/schema";
import { formatCurrency } from "@/utils/formatters";

interface AccountCardProps {
  account: Account;
  onTransfer: () => void;
  onViewDetails: () => void;
}

export default function AccountCard({ account, onTransfer, onViewDetails }: AccountCardProps) {
  const getAccountIcon = (type: string) => {
    switch (type) {
      case "checking":
        return <Building2 className="w-6 h-6 text-blue-600" />;
      case "savings":
        return <PiggyBank className="w-6 h-6 text-green-600" />;
      case "credit":
        return <CreditCard className="w-6 h-6 text-orange-600" />;
      default:
        return <Building2 className="w-6 h-6 text-blue-600" />;
    }
  };

  const getIconBackground = (type: string) => {
    switch (type) {
      case "checking":
        return "bg-blue-100";
      case "savings":
        return "bg-green-100";
      case "credit":
        return "bg-orange-100";
      default:
        return "bg-blue-100";
    }
  };

  const displayBalance = account.type === "credit" 
    ? account.availableCredit 
    : account.balance;

  const balanceLabel = account.type === "credit" 
    ? "Available Credit" 
    : formatCurrency(account.balance);

  return (
    <Card className="banking-card-hover banking-shadow border border-slate-200">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center mb-3 sm:mb-0">
            <div className="flex-shrink-0">
              <div className={`w-10 h-10 sm:w-12 sm:h-12 ${getIconBackground(account.type)} rounded-lg flex items-center justify-center`}>
                {getAccountIcon(account.type)}
              </div>
            </div>
            <div className="ml-3 sm:ml-4">
              <h3 className="mobile-text-label font-medium text-slate-900">{account.name}</h3>
              <p className="text-xs sm:text-sm text-slate-500 font-mono">{account.accountNumber}</p>
              <p className="text-xs text-slate-400 font-mono">Routing: {account.routingNumber || "111925113"}</p>
            </div>
          </div>
          <div className="text-left sm:text-right">
            <p className="mobile-text-balance font-semibold text-slate-900">
              {formatCurrency(displayBalance || "0")}
            </p>
            {account.type === "credit" ? (
              <p className="text-xs sm:text-sm text-slate-500">Available Credit</p>
            ) : (
              <p className="text-xs sm:text-sm text-green-600 flex items-center sm:justify-end">
                <TrendingUp className="w-3 h-3 mr-1" />
                +2.4%
              </p>
            )}
          </div>
        </div>

        {account.type === "credit" && (
          <div className="mt-4">
            <div className="flex justify-between text-xs text-slate-600">
              <span>Used: {formatCurrency(account.balance)}</span>
              <span>Limit: {formatCurrency(account.creditLimit || "0")}</span>
            </div>
            <div className="mt-2 w-full bg-slate-200 rounded-full h-2">
              <div 
                className="bg-orange-500 h-2 rounded-full" 
                style={{ 
                  width: `${Math.min((parseFloat(account.balance || "0") / parseFloat(account.creditLimit || "1")) * 100, 100)}%` 
                }}
              ></div>
            </div>
          </div>
        )}

        <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row gap-2 sm:gap-3">
          <Button 
            onClick={onTransfer}
            className="flex-1 touch-target bg-blue-600 text-white text-sm font-medium py-3 sm:py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-200"
            data-testid="button-transfer"
          >
            {account.type === "credit" ? "Draw Funds" : "Transfer"}
          </Button>
          <Button 
            onClick={onViewDetails}
            variant="outline"
            className="flex-1 touch-target bg-slate-100 text-slate-700 text-sm font-medium py-3 sm:py-2 px-4 rounded-md hover:bg-slate-200 transition-colors duration-200"
            data-testid="button-view-details"
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}