import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Download, Eye } from "lucide-react";
import { Account } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface StatementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
}

interface Statement {
  id: string;
  month: string;
  year: number;
  accountId: string;
  status: 'available' | 'processing';
  size: string;
}

const mockStatements: Statement[] = [
  { id: '1', month: 'July', year: 2025, accountId: 'all', status: 'available', size: '2.1 MB' },
  { id: '2', month: 'June', year: 2025, accountId: 'all', status: 'available', size: '1.8 MB' },
  { id: '3', month: 'May', year: 2025, accountId: 'all', status: 'available', size: '2.3 MB' },
  { id: '4', month: 'April', year: 2025, accountId: 'all', status: 'available', size: '1.9 MB' },
  { id: '5', month: 'March', year: 2025, accountId: 'all', status: 'processing', size: '-- MB' },
];

export default function StatementsModal({ isOpen, onClose, accounts }: StatementsModalProps) {
  const [selectedAccount, setSelectedAccount] = useState("all");
  const [selectedYear, setSelectedYear] = useState("2025");
  const { toast } = useToast();

  const handleDownload = (statement: Statement) => {
    toast({
      title: "Statement Downloaded",
      description: `${statement.month} ${statement.year} statement has been downloaded.`,
    });
  };

  const handleView = (statement: Statement) => {
    toast({
      title: "Opening Statement",
      description: `Opening ${statement.month} ${statement.year} statement in a new window.`,
    });
  };

  const filteredStatements = mockStatements.filter(statement => {
    return selectedAccount === 'all' || statement.accountId === selectedAccount;
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <FileText className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <DialogTitle>Account Statements</DialogTitle>
              <DialogDescription>View and download your account statements</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex space-x-4">
            <div className="flex-1">
              <label className="text-sm font-medium text-slate-700">Account</label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Accounts</SelectItem>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium text-slate-700">Year</label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3 max-h-64 overflow-y-auto">
            {filteredStatements.map((statement) => (
              <Card key={statement.id} className="hover:bg-slate-50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                        <FileText className="h-5 w-5 text-slate-600" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">
                          {statement.month} {statement.year} Statement
                        </p>
                        <p className="text-sm text-slate-500">
                          {statement.status === 'available' ? `PDF • ${statement.size}` : 'Processing...'}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {statement.status === 'available' ? (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleView(statement)}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownload(statement)}
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                        </>
                      ) : (
                        <Button variant="outline" size="sm" disabled>
                          Processing
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>Note:</strong> Statements are available for download up to 7 years. 
              For older statements, please contact customer service.
            </p>
          </div>

          <div className="flex justify-end pt-4">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}