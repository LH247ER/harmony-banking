import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Building2,
  ArrowLeftRight,
  Receipt,
  BarChart3,
  Settings,
  X
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Accounts", href: "/accounts", icon: Building2 },
  { name: "Transfers", href: "/transfers", icon: ArrowLeftRight },
  { name: "Bills & Payments", href: "/payments", icon: Receipt },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-40 lg:hidden" onClick={onClose}>
          <div className="fixed inset-0 bg-slate-600 bg-opacity-75" />
        </div>
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 card-backdrop border-r border-slate-200 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto">
          {/* Mobile close button */}
          <div className="flex items-center justify-between px-6 lg:hidden">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <img src="/logo-accent.svg" alt="Harmony" className="w-8 h-8" />
              </div>
              <span className="ml-3 text-xl font-semibold text-readable">Harmony</span>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Desktop logo */}
          <div className="hidden lg:flex items-center flex-shrink-0 px-6">
            <div className="w-8 h-8 flex items-center justify-center">
              <img src="/logo-accent.svg" alt="Harmony" className="w-8 h-8" />
            </div>
          </div>

          <div className="mt-8 flex-grow flex flex-col">
            <nav className="flex-1 px-4 space-y-1">
              {navigation.map((item) => {
                const isActive = location === item.href || (location === "/" && item.href === "/dashboard");
                return (
                  <Link key={item.name} href={item.href}>
                    <div
                      className={cn(
                        "group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer text-readable",
                        isActive
                          ? "bg-blue-50 border-r-2 border-blue-600 text-blue-700"
                          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                      )}
                      onClick={() => onClose()}
                    >
                      <item.icon
                        className={cn(
                          "mr-3 h-5 w-5",
                          isActive ? "text-blue-500" : "text-slate-400 group-hover:text-slate-500"
                        )}
                      />
                      {item.name}
                    </div>
                  </Link>
                );
              })}
            </nav>

            <div className="flex-shrink-0 px-4 py-4 space-y-1">
              <Link href="/settings">
                <div className="text-slate-600 hover:bg-slate-50 hover:text-slate-900 group flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer text-readable">
                  <Settings className="text-slate-400 group-hover:text-slate-500 mr-3 h-5 w-5" />
                  Settings
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
      {/* Background Image */}
      <div className="fixed inset-0 z-0">
        <img src="/bg-login.gif" alt="Background" className="w-full h-full object-cover" />
      </div>
    </>
  );
}