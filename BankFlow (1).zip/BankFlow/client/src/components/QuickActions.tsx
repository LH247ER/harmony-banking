import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeftRight, Receipt, Camera, FileText } from "lucide-react";

interface QuickActionsProps {
  onTransfer: () => void;
  onBillPay: () => void;
  onMobileDeposit: () => void;
  onViewStatements: () => void;
  className?: string;
}

export default function QuickActions({ 
  onTransfer, 
  onBillPay, 
  onMobileDeposit, 
  onViewStatements, 
  className 
}: QuickActionsProps) {
  const actions = [
    {
      icon: ArrowLeftRight,
      title: "Transfer Money",
      description: "Between accounts or to external",
      onClick: onTransfer,
      color: "bg-blue-100 text-blue-600",
    },
    {
      icon: Receipt,
      title: "Pay Bills",
      description: "Schedule or pay immediately",
      onClick: onBillPay,
      color: "bg-green-100 text-green-600",
    },
    {
      icon: Camera,
      title: "Mobile Deposit",
      description: "Deposit checks with your phone",
      onClick: onMobileDeposit,
      color: "bg-blue-100 text-blue-600",
    },
    {
      icon: FileText,
      title: "View Statements",
      description: "Download or view past statements",
      onClick: onViewStatements,
      color: "bg-purple-100 text-purple-600",
    },
  ];

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-lg font-medium text-slate-900">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              onClick={action.onClick}
              className="w-full flex items-center p-4 h-auto border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors duration-200"
            >
              <div className={`flex-shrink-0 w-10 h-10 ${action.color} rounded-lg flex items-center justify-center`}>
                <action.icon className="w-5 h-5" />
              </div>
              <div className="ml-4 text-left">
                <p className="text-sm font-medium text-slate-900">{action.title}</p>
                <p className="text-xs text-slate-500">{action.description}</p>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
