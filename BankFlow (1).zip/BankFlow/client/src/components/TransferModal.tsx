import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeftRight, AlertTriangle, Building2, CreditCard } from "lucide-react";
import { Account } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { formatCurrency } from "@/utils/formatters";

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
}

export default function TransferModal({ isOpen, onClose, accounts }: TransferModalProps) {
  const { user } = useAuth();
  const [transferType, setTransferType] = useState("internal");
  const [fromAccountId, setFromAccountId] = useState("");
  const [toAccountId, setToAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  
  // External transfer fields
  const [recipientName, setRecipientName] = useState("");
  const [recipientAccountNumber, setRecipientAccountNumber] = useState("");
  const [recipientRoutingNumber, setRecipientRoutingNumber] = useState("");
  const [recipientBankName, setRecipientBankName] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const transferMutation = useMutation({
    mutationFn: async (transferData: {
      fromAccountId: string;
      toAccountId: string;
      amount: string;
      description?: string;
      status: string;
    }) => {
      console.log("Making transfer API request:", transferData);
      
      try {
        const response = await fetch("/api/transfers", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(transferData),
        });

        console.log("Response status:", response.status);
        console.log("Response headers:", Object.fromEntries(response.headers.entries()));

        if (!response.ok) {
          const errorText = await response.text();
          console.log("Error response text:", errorText);
          
          let errorMessage = "Transfer failed";
          try {
            const errorData = JSON.parse(errorText);
            errorMessage = errorData.message || errorMessage;
          } catch {
            errorMessage = errorText || errorMessage;
          }
          
          throw new Error(errorMessage);
        }
        
        const result = await response.json();
        console.log("Transfer successful:", result);
        return result;
      } catch (error) {
        console.error("Transfer request error:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("Transfer successful:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transfers"] });
      
      const sourceAccount = accounts.find(acc => acc.id === fromAccountId);
      const destinationAccount = accounts.find(acc => acc.id === toAccountId);
      
      toast({
        title: "✅ Transfer Completed",
        description: `Successfully transferred $${parseFloat(amount).toLocaleString()} from ${sourceAccount?.name} to ${destinationAccount?.name}.`,
        duration: 5000,
      });
      handleClose();
    },
    onError: (error: any) => {
      console.error("Transfer failed:", error);
      console.error("Error details:", JSON.stringify(error, null, 2));
      toast({
        title: "Transfer Failed",
        description: error.message || "An error occurred during the transfer. Please check the console for more details.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log("Transfer form submitted:", { transferType, fromAccountId, toAccountId, amount });
    console.log("Available accounts:", accounts.map(acc => ({ id: acc.id, name: acc.name, accountNumber: acc.accountNumber })));
    
    // Validate required fields for all transfer types
    if (!fromAccountId || !amount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const transferAmount = parseFloat(amount);
    if (isNaN(transferAmount) || transferAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      });
      return;
    }

    // For external transfers (ACH/Wire), validate all fields first
    if (transferType === "ach" || transferType === "wire") {
      // Validate external transfer specific fields
      if (!recipientName || !recipientAccountNumber || !recipientRoutingNumber || !recipientBankName) {
        toast({
          title: "Missing Recipient Information",
          description: "Please fill in all recipient banking details.",
          variant: "destructive",
        });
        return;
      }

      // Validate recipient routing number format (9 digits)
      if (recipientRoutingNumber.length !== 9 || !/^\d{9}$/.test(recipientRoutingNumber)) {
        toast({
          title: "Invalid Routing Number",
          description: "Routing number must be exactly 9 digits.",
          variant: "destructive",
        });
        return;
      }

      // Validate recipient account number (basic validation)
      if (recipientAccountNumber.length < 4) {
        toast({
          title: "Invalid Account Number",
          description: "Account number must be at least 4 digits.",
          variant: "destructive",
        });
        return;
      }
    }
    
    // Internal transfers specific validation
    if (transferType === "internal") {
      if (!toAccountId) {
        toast({
          title: "Missing Information",
          description: "Please select a destination account.",
          variant: "destructive",
        });
        return;
      }

      if (fromAccountId === toAccountId) {
        toast({
          title: "Invalid Transfer",
          description: "Cannot transfer to the same account.",
          variant: "destructive",
        });
        return;
      }
    }

    // Show account review warning for ALL transfer types
    toast({
      title: "⚠️ Account Under Review",
      description: `Your bank account is under review and can't make any ${transferType === "internal" ? "internal" : transferType.toUpperCase()} transactions at the moment till the bank finalizes the review. Sometimes this may take longer than expected, so please be advised to reach out to the bank or wait till the account gets back to normal. Thanks for banking with us, ${user?.name || 'valued customer'}.`,
      variant: "destructive",
      duration: 10000,
    });
    return;

    
  };

  const handleClose = () => {
    setTransferType("internal");
    setFromAccountId("");
    setToAccountId("");
    setAmount("");
    setDescription("");
    setRecipientName("");
    setRecipientAccountNumber("");
    setRecipientRoutingNumber("");
    setRecipientBankName("");
    onClose();
  };

  const availableToAccounts = accounts.filter(account => account.id !== fromAccountId);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[95vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <ArrowLeftRight className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <DialogTitle>Transfer Funds</DialogTitle>
              <DialogDescription>Send money between accounts or to external recipients</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="max-h-[70vh] overflow-y-auto mobile-scroll">
          <Tabs value={transferType} onValueChange={setTransferType} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="internal" className="flex items-center space-x-1 text-xs sm:text-sm px-2 sm:px-4">
                <CreditCard className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Internal</span>
                <span className="sm:hidden">Int</span>
              </TabsTrigger>
              <TabsTrigger value="ach" className="flex items-center space-x-1 text-xs sm:text-sm px-2 sm:px-4">
                <Building2 className="w-3 h-3 sm:w-4 sm:h-4" />
                <span>ACH</span>
              </TabsTrigger>
              <TabsTrigger value="wire" className="flex items-center space-x-1 text-xs sm:text-sm px-2 sm:px-4">
                <AlertTriangle className="w-3 h-3 sm:w-4 sm:h-4" />
                <span>Wire</span>
              </TabsTrigger>
            </TabsList>

          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="fromAccount">From Account</Label>
              <Select value={fromAccountId} onValueChange={setFromAccountId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select source account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} ({account.accountNumber}) - ${parseFloat(account.balance).toLocaleString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <TabsContent value="internal" className="space-y-4 m-0">
              <div className="space-y-2">
                <Label htmlFor="toAccount">To Account</Label>
                <Select value={toAccountId} onValueChange={setToAccountId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select destination account" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableToAccounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.name} ({account.accountNumber})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            <TabsContent value="ach" className="space-y-4 m-0 max-h-[400px] overflow-y-auto">
              <Alert className="border-orange-200 bg-orange-50">
                <AlertTriangle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-orange-800">
                  ACH transfers typically take 1-3 business days to process and have lower fees. Please verify all recipient information carefully.
                </AlertDescription>
              </Alert>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 sm:p-4">
                <h4 className="text-sm font-medium text-slate-900 mb-2">Your Bank Information</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-slate-500">Your Routing Number:</span>
                    <p className="font-mono font-medium">111925113</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Bank Name:</span>
                    <p className="font-medium">Harmony Business Bank</p>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="recipientName" className="text-sm font-medium">Recipient Name</Label>
                  <Input
                    id="recipientName"
                    data-testid="input-recipient-name"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="Full name on account"
                    className="mobile-input-height"
                    required={transferType === "ach"}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="recipientBankName" className="text-sm font-medium">Bank Name</Label>
                  <Input
                    id="recipientBankName"
                    data-testid="input-recipient-bank"
                    value={recipientBankName}
                    onChange={(e) => setRecipientBankName(e.target.value)}
                    placeholder="Bank name"
                    className="mobile-input-height"
                    required={transferType === "ach"}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="recipientRoutingNumber" className="text-sm font-medium">Routing Number</Label>
                  <Input
                    id="recipientRoutingNumber"
                    data-testid="input-recipient-routing"
                    value={recipientRoutingNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, ''); // Only allow digits
                      setRecipientRoutingNumber(value);
                    }}
                    placeholder="9-digit routing number"
                    maxLength={9}
                    className="mobile-input-height font-mono"
                    inputMode="numeric"
                    required={transferType === "ach"}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="recipientAccountNumber" className="text-sm font-medium">Account Number</Label>
                  <Input
                    id="recipientAccountNumber"
                    data-testid="input-recipient-account"
                    value={recipientAccountNumber}
                    onChange={(e) => setRecipientAccountNumber(e.target.value)}
                    placeholder="Account number"
                    className="mobile-input-height font-mono"
                    inputMode="numeric"
                    required={transferType === "ach"}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="wire" className="space-y-4 m-0 max-h-[400px] overflow-y-auto">
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  Wire transfers are processed same-day but have higher fees ($25-$50). They cannot be reversed once sent. Please verify all recipient information carefully.
                </AlertDescription>
              </Alert>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 sm:p-4">
                <h4 className="text-sm font-medium text-slate-900 mb-2">Your Bank Information</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-slate-500">Your Routing Number:</span>
                    <p className="font-mono font-medium">111925113</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Bank Name:</span>
                    <p className="font-medium">Harmony Business Bank</p>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wireRecipientName" className="text-sm font-medium">Recipient Name</Label>
                  <Input
                    id="wireRecipientName"
                    data-testid="input-wire-recipient-name"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="Full name on account"
                    className="mobile-input-height"
                    required={transferType === "wire"}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wireBankName" className="text-sm font-medium">Bank Name</Label>
                  <Input
                    id="wireBankName"
                    data-testid="input-wire-bank"
                    value={recipientBankName}
                    onChange={(e) => setRecipientBankName(e.target.value)}
                    placeholder="Bank name"
                    className="mobile-input-height"
                    required={transferType === "wire"}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="wireRoutingNumber" className="text-sm font-medium">Routing Number</Label>
                  <Input
                    id="wireRoutingNumber"
                    data-testid="input-wire-routing"
                    value={recipientRoutingNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, ''); // Only allow digits
                      setRecipientRoutingNumber(value);
                    }}
                    placeholder="9-digit routing number"
                    maxLength={9}
                    className="mobile-input-height font-mono"
                    inputMode="numeric"
                    required={transferType === "wire"}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wireAccountNumber" className="text-sm font-medium">Account Number</Label>
                  <Input
                    id="wireAccountNumber"
                    data-testid="input-wire-account"
                    value={recipientAccountNumber}
                    onChange={(e) => setRecipientAccountNumber(e.target.value)}
                    placeholder="Account number"
                    className="mobile-input-height font-mono"
                    inputMode="numeric"
                    required={transferType === "wire"}
                  />
                </div>
              </div>
            </TabsContent>

            <div className="space-y-2">
              <Label htmlFor="amount" className="text-sm font-medium">Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
                <Input
                  id="amount"
                  data-testid="input-transfer-amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="pl-8 mobile-input-height"
                  inputMode="decimal"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-medium">Description (Optional)</Label>
              <Textarea
                id="description"
                data-testid="input-transfer-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter transfer description..."
                rows={2}
                className="resize-none mobile-input-height"
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <Button
                type="submit"
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
                disabled={transferMutation.isPending}
              >
                {transferMutation.isPending ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Processing Transfer...</span>
                  </div>
                ) : (
                  transferType === "internal" ? "Transfer Now" :
                  transferType === "ach" ? "Send ACH Transfer" :
                  "Send Wire Transfer"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}