import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Receipt } from "lucide-react";
import { Account } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface BillPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
}

export default function BillPaymentModal({ isOpen, onClose, accounts }: BillPaymentModalProps) {
  const [accountId, setAccountId] = useState("");
  const [payeeName, setPayeeName] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [payDate, setPayDate] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const payBillMutation = useMutation({
    mutationFn: async (billData: {
      accountId: string;
      description: string;
      amount: string;
      type: string;
      status: string;
      reference: string;
    }) => {
      const response = await apiRequest("POST", "/api/transactions", billData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Bill Payment Scheduled",
        description: "Your bill payment has been processed successfully.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Payment Failed",
        description: error.message || "An error occurred while processing the payment.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!accountId || !payeeName || !amount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const paymentAmount = parseFloat(amount);
    if (isNaN(paymentAmount) || paymentAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      });
      return;
    }

    payBillMutation.mutate({
      accountId,
      description: `Bill Payment - ${payeeName}`,
      amount: `-${paymentAmount.toString()}`,
      type: "debit",
      status: payDate ? "pending" : "completed",
      reference: `${payeeName} - ${description || "Bill Payment"}`,
    });
  };

  const handleClose = () => {
    setAccountId("");
    setPayeeName("");
    setAmount("");
    setDescription("");
    setPayDate("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Receipt className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <DialogTitle>Pay Bill</DialogTitle>
              <DialogDescription>Schedule or pay a bill immediately</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="account">Pay From Account</Label>
            <Select value={accountId} onValueChange={setAccountId}>
              <SelectTrigger>
                <SelectValue placeholder="Select account" />
              </SelectTrigger>
              <SelectContent>
                {accounts.map((account) => (
                  <SelectItem key={account.id} value={account.id}>
                    {account.name} ({account.accountNumber})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="payee">Payee Name</Label>
            <Input
              id="payee"
              type="text"
              value={payeeName}
              onChange={(e) => setPayeeName(e.target.value)}
              placeholder="Enter payee name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="pl-8"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="payDate">Pay Date (Optional)</Label>
            <Input
              id="payDate"
              type="date"
              value={payDate}
              onChange={(e) => setPayDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
            />
            <p className="text-xs text-slate-500">Leave blank to pay immediately</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Memo (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Payment description or account number..."
              rows={2}
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="submit"
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={payBillMutation.isPending}
            >
              {payBillMutation.isPending ? "Processing..." : payDate ? "Schedule Payment" : "Pay Now"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}