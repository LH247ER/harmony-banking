
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, PiggyBank, CreditCard, Calendar, DollarSign, Hash, CheckCircle } from "lucide-react";
import { Account } from "@shared/schema";
import { formatCurrency } from "@/utils/formatters";

interface AccountDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: Account | null;
}

export default function AccountDetailsModal({ isOpen, onClose, account }: AccountDetailsModalProps) {
  if (!account) return null;

  const getAccountIcon = (type: string) => {
    switch (type) {
      case "checking":
        return <Building2 className="w-6 h-6 text-blue-600" />;
      case "savings":
        return <PiggyBank className="w-6 h-6 text-green-600" />;
      case "credit":
        return <CreditCard className="w-6 h-6 text-orange-600" />;
      default:
        return <Building2 className="w-6 h-6 text-blue-600" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            {getAccountIcon(account.type)}
            {account.name} Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Account Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Account Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-500">Account Number</span>
                  </div>
                  <p className="font-medium font-mono">{account.accountNumber}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-500">Routing Number</span>
                  </div>
                  <p className="font-medium font-mono">{account.routingNumber || "111925113"}</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-500">Current Balance</span>
                  </div>
                  <p className="text-2xl font-semibold text-slate-900">
                    {formatCurrency(account.balance)}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-500">Status</span>
                  </div>
                  <Badge variant={account.isActive ? "default" : "secondary"}>
                    {account.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Type Specific Info */}
          {account.type === "credit" && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Credit Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <span className="text-sm text-slate-500">Available Credit</span>
                    <p className="text-xl font-semibold text-green-600">
                      {formatCurrency(account.availableCredit || "0")}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-sm text-slate-500">Credit Limit</span>
                    <p className="text-xl font-semibold">
                      {formatCurrency(account.creditLimit || "0")}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-sm text-slate-500">Used Credit</span>
                    <p className="text-xl font-semibold text-orange-600">
                      {formatCurrency(account.balance)}
                    </p>
                  </div>
                </div>
                
                {/* Credit Usage Bar */}
                <div className="mt-4">
                  <div className="flex justify-between text-sm text-slate-600 mb-2">
                    <span>Credit Utilization</span>
                    <span>
                      {Math.round((parseFloat(account.balance || "0") / parseFloat(account.creditLimit || "1")) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-3">
                    <div 
                      className="bg-orange-500 h-3 rounded-full transition-all duration-300" 
                      style={{ 
                        width: `${Math.min((parseFloat(account.balance || "0") / parseFloat(account.creditLimit || "1")) * 100, 100)}%` 
                      }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Account Features */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Account Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm font-medium">Online Banking</span>
                  <Badge variant="default">Enabled</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm font-medium">Mobile Deposits</span>
                  <Badge variant="default">Enabled</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm font-medium">Wire Transfers</span>
                  <Badge variant="default">Enabled</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <span className="text-sm font-medium">Overdraft Protection</span>
                  <Badge variant={account.type === "checking" ? "default" : "secondary"}>
                    {account.type === "checking" ? "Enabled" : "N/A"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
