import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Transaction, Account } from "@shared/schema";
import { formatCurrency, formatDate, getTransactionColor, getStatusColor } from "@/utils/formatters";

interface TransactionTableProps {
  transactions: Transaction[];
  accounts: Account[];
  isLoading?: boolean;
}

export default function TransactionTable({ transactions, accounts, isLoading }: TransactionTableProps) {
  const [selectedAccount, setSelectedAccount] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const filteredTransactions = transactions.filter(transaction => 
    selectedAccount === "all" || transaction.accountId === selectedAccount
  );

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + itemsPerPage);

  const getAccountName = (accountId: string) => {
    const account = accounts.find(acc => acc.id === accountId);
    return account?.name || "Unknown Account";
  };

  if (isLoading) {
    return (
      <div className="bg-white shadow-sm rounded-lg border border-slate-200">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-slate-200 rounded w-1/4"></div>
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 bg-slate-100 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-sm rounded-lg border border-slate-200">
      <div className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <h3 className="mobile-text-heading font-medium text-slate-900">Recent Transactions</h3>
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="flex items-center space-x-2">
              <label className="text-sm text-slate-600 hidden sm:block">Filter:</label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger className="w-full sm:w-48" data-testid="select-account-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Accounts</SelectItem>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button 
              variant="link" 
              className="text-blue-600 hover:text-blue-700 text-sm font-medium p-0 self-start sm:self-auto"
              data-testid="button-view-all-transactions"
            >
              View All
            </Button>
          </div>
        </div>

        <div className="table-mobile overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead className="text-xs font-medium text-slate-500 uppercase tracking-wider">Date</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 uppercase tracking-wider">Description</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 uppercase tracking-wider">Account</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 uppercase tracking-wider">Amount</TableHead>
                <TableHead className="text-xs font-medium text-slate-500 uppercase tracking-wider">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedTransactions.map((transaction) => (
                <TableRow key={transaction.id} className="hover:bg-slate-50 transition-colors duration-150">
                  <TableCell className="text-sm text-slate-900">
                    {formatDate(transaction.date)}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm text-slate-900">{transaction.description}</div>
                    {transaction.reference && (
                      <div className="text-xs text-slate-500">{transaction.reference}</div>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {getAccountName(transaction.accountId)}
                  </TableCell>
                  <TableCell className={`text-sm font-medium ${getTransactionColor(transaction.amount)}`}>
                    {parseFloat(transaction.amount) >= 0 ? '+' : ''}{formatCurrency(transaction.amount)}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={getStatusColor(transaction.status)}>
                      {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-white px-4 py-3 sm:px-6 mt-4">
          <div className="flex flex-1 justify-between sm:hidden">
            <Button
              variant="outline"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
          <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-slate-700">
                Showing <span className="font-medium">{startIndex + 1}</span> to{" "}
                <span className="font-medium">{Math.min(startIndex + itemsPerPage, filteredTransactions.length)}</span> of{" "}
                <span className="font-medium">{filteredTransactions.length}</span> results
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-slate-700">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
